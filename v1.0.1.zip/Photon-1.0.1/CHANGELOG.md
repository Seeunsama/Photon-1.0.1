## v1.0.0
First stable release.

#### v1.0.1
- Disabled colors on windows and mac
- Cross platform file handling
